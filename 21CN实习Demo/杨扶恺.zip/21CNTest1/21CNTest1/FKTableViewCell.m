//
//  FKTableViewCell.m
//  21CNTest1
//
//  Created by CodingDoge on 16/8/4.
//  Copyright © 2016年 CodingDoge. All rights reserved.
//

#import "FKTableViewCell.h"

@implementation FKTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
