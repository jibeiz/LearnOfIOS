//
//  ViewController.m
//  21CNTest1
//
//  Created by CodingDoge on 16/8/4.
//  Copyright © 2016年 CodingDoge. All rights reserved.
//

#import "ViewController.h"
#import "OneImageViewController.h"
#import "ListImageTableViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Segue
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.destinationViewController isKindOfClass: [OneImageViewController class]])
    {
        OneImageViewController *ivr = (OneImageViewController *)segue.destinationViewController;
            ivr.imageURL = [NSURL URLWithString: @"http://static.21cnimg.com/css/index/bgimg/21cn_logo.png?v20130806"];
        NSLog(@"****");
    }
    else if([segue.destinationViewController isKindOfClass: [ListImageTableViewController class]])
    {
        ListImageTableViewController *ivr = (ListImageTableViewController *)segue.destinationViewController;
        ivr.path =  [[NSBundle mainBundle] pathForResource:@"data" ofType:@"json"];
//        NSLog(@"path:%@", ivr.path);
        ivr.jsonData = [NSData dataWithContentsOfFile:ivr.path options:NSDataReadingMappedIfSafe error:nil];
//        NSLog(@"jsonData:%@", ivr.jsonData);

    }

}
@end
