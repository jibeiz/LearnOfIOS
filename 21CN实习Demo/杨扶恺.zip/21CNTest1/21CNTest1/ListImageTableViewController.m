//
//  ListImageTableViewController.m
//  21CNTest1
//
//  Created by CodingDoge on 16/8/4.
//  Copyright © 2016年 CodingDoge. All rights reserved.
//

#import "ListImageTableViewController.h"
#import "FKTableViewCell.h"

@interface ListImageTableViewController ()
@property (nonatomic, strong)NSMutableArray *dataDict;

@end

@implementation ListImageTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSError *error = [[NSError alloc] init];
    self.dataDict = [NSJSONSerialization JSONObjectWithData:self.jsonData options:NSJSONReadingAllowFragments error: &error];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark --UITableViewDataSource 协议方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.dataDict count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSLog(@"tableView");
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"FKCellIdentifier"];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FKCellIdentifier" forIndexPath:indexPath];
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleSubtitle reuseIdentifier: @"FKCellIdentifier"];
    }
    
    // 获取节和行
    NSUInteger row = [indexPath row];
    
    NSDictionary *rowDict = self.dataDict[row];
    cell.textLabel.text = rowDict[@"title"];
    
    NSString *urlPath = rowDict[@"url"];
    NSLog(@"url:%@", urlPath);
    NSURL *imageURL = [NSURL URLWithString: urlPath];
    NSLog(@"imageURL:%@", imageURL);
    //cell.imageView.frame = CGRectMake(<#CGFloat x#>, <#CGFloat y#>, <#CGFloat width#>, <#CGFloat height#>);
    if(imageURL)
    {
        NSURLRequest *request = [NSURLRequest requestWithURL: imageURL];
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration ephemeralSessionConfiguration];
        NSURLSession *session = [NSURLSession sessionWithConfiguration: configuration];
        NSURLSessionDownloadTask *task = [session downloadTaskWithRequest: request completionHandler: ^(NSURL *localfile, NSURLResponse *response, NSError *error){
            if(!error)
            {
                NSLog(@"if !error");
                if([request.URL isEqual: imageURL])
                {
                    NSLog(@"if after.");
                    UIImage *image = [UIImage imageWithData: [NSData dataWithContentsOfURL: localfile]];
                    dispatch_async(dispatch_get_main_queue(), ^{[cell.imageView sizeToFit]; cell.imageView.image = image;});
                }
            }
        }];
        [task resume];
    }
    //cell.imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:imageURL]];
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}



@end
