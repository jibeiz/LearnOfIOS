//
//  OneImageViewController.m
//  21CNTest1
//
//  Created by CodingDoge on 16/8/4.
//  Copyright © 2016年 CodingDoge. All rights reserved.
//

#import "OneImageViewController.h"

@interface OneImageViewController ()

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *spinner;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property(nonatomic, strong) UIImage *image;
- (IBAction)returnToFirstPage:(id)sender;

@end

@implementation OneImageViewController

-(void) setImageURL:(NSURL *)imageURL
{
    _imageURL = imageURL;
    [self.spinner startAnimating];
    [self startDownloadingImage];
    
}

#pragma mark - Image
-(void) setImage: (UIImage *)image
{
    self.imageView.image = image;
    [self.imageView sizeToFit];
    [self.spinner stopAnimating];
}

-(UIImage *)image
{
    return self.imageView.image;
}






#pragma mark - Download
-(void) startDownloadingImage
{
    self.image = nil;
    NSLog(@"startDownloadingImage is called.");
    if(self.imageURL)
    {
        [self.spinner startAnimating];
        NSURLRequest *request = [NSURLRequest requestWithURL: self.imageURL];
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration ephemeralSessionConfiguration];
        NSURLSession *session = [NSURLSession sessionWithConfiguration: configuration];
        NSURLSessionDownloadTask *task = [session downloadTaskWithRequest: request completionHandler: ^(NSURL *localfile, NSURLResponse *response, NSError *error){
            if(!error)
            {
                NSLog(@"if !error");
                if([request.URL isEqual: self.imageURL])
                {
                    NSLog(@"if after.");
                    UIImage *image = [UIImage imageWithData: [NSData dataWithContentsOfURL: localfile]];
                    dispatch_async(dispatch_get_main_queue(), ^{self.image = image;});
                }
            }
        }];
        [task resume];
    }
}

#pragma mark - ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.imageView.image = self.image;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    //    NSLog(@"ImageViewController didReceiveMemoryWarning.");
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)returnToFirstPage:(id)sender {
    [self dismissViewControllerAnimated:NO completion:^(void){
        NSLog(@"return");
    }];
}
@end
