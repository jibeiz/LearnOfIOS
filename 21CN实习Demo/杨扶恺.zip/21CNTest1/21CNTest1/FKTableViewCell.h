//
//  FKTableViewCell.h
//  21CNTest1
//
//  Created by CodingDoge on 16/8/4.
//  Copyright © 2016年 CodingDoge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FKTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageCell;
@property (weak, nonatomic) IBOutlet UILabel *labelCell;

@end
