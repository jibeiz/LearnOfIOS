//
//  OneImageViewController.h
//  21CNTest1
//
//  Created by CodingDoge on 16/8/4.
//  Copyright © 2016年 CodingDoge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneImageViewController : UIViewController

@property (nonatomic, strong) NSURL *imageURL;
- (IBAction)returnToFirstPage:(id)sender;

@end
