//
//  SampleConstants.h
//  InterstitialExample
//
//  Copyright 2013 Google Inc. All rights reserved.
//

// You should set this ad unit ID from your account before compiling.
// For new AdMob, this is ca-app-pub/XXXXXXXXXXXXXXXX/NNNNNNNNNN
// For DFP, this is /<networkCode>/<adUnitName>
// For Ad Exchange, this is <google_ad_client>/<google_ad_slot>
#define kSampleAdUnitID @"INSERT_AD_UNIT_ID_HERE"
